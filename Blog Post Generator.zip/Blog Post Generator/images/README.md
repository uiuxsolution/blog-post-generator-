This directory contains all the images used in the fashion website.
