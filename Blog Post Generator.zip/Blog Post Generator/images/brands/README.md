This directory contains brand logo images.

Required images:
1. hm.png - H&M logo
2. uniqlo.png - Uniqlo logo
3. shopify.png - Shopify logo
4. lacoste.png - Lacoste logo
5. levis.png - Levi's logo
6. amazon.png - Amazon logo

Please add these brand logo images in PNG format to this directory.
